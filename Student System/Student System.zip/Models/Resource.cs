﻿using System;
using System.Collections.Generic;
using System.Security.AccessControl;
using System.Text;

namespace P01_StudentSystem.Models
{
    enum ResourceType
    {
        Video,
        Presentation,
        Document,
        Other
    }

    internal class Resource
    {
        public int ResourceId { get; set; }

        public string Name { get; set; } = string.Empty;

        public string URL { get; set; } = string.Empty;

        public ResourceType ResourceType { get; set; }

        public int CourseId { get; set; }

        public Course Course { get; set; } = new();


    }
}
