﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Models
{
    internal class Student
    {
        public int StudentId { get; set; }

        public string Name { get; set; } = string.Empty;

        public string? PhoneNumber { get; set; }

        public DateTime RegisteredOn { get; set; }

        public DateTime? BirthDay { get; set; }

        public ICollection<Course> Courses { get; set; } = new List<Course>();

        public ICollection<HomeWorkSubmissions> HomeWorkSubmissions { get; set; } = new List<HomeWorkSubmissions>();

        public ICollection<StudentCourse> StudentCourses { get; set; } = new List<StudentCourse>();
    }
}
